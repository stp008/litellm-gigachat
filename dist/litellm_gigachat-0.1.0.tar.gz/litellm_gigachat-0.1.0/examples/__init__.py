"""
Примеры использования LiteLLM GigaChat Integration.
"""
