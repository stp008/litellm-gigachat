"""
Тесты для LiteLLM GigaChat Integration.
"""
