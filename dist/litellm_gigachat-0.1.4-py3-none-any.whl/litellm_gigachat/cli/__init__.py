"""
CLI модуль для litellm-gigachat.
"""

from .main import cli

__all__ = ['cli']
